$('.hammer_example').hover(function() {
  	// Add .hammered to .good_hammer
  $('.hammer_example').addClass('hammered');
  
  setTimeout(function() {
    $('.hammer_example').removeClass('hammered');
  }, 200);
});